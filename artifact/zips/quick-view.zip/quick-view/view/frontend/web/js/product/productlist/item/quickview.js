 define([
  'jquery',
  'Magento_Ui/js/modal/modal',
  'mage/loader',
  'Magento_Customer/js/customer-data',
  'jquery/ui'
  ], function ($, modal, loader, customerData) {
    'use strict';
    return function(config, node) {
      var product_id = $(node).data('id');
      var product_url = $(node).data('url');
      var options = {
        type: 'popup',
        responsive: true,
        innerScroll: false,
        clickableOverlay: false,
        title: $('#QuickViewPopupHeaderTitle').val(),
        buttons: [{
          text: $('#QuickViewPopupCloseButton').val(),
          class: 'close-modal fme-model-close',
          click: function () {
            var sections = ['cart'];
            customerData.invalidate(sections);
            customerData.reload(sections, true);
            this.closeModal();
          }
        }]
      };
      var popup = modal(options, $('#quickViewContainer' + product_id));

      $("#quickViewButton" + product_id).on("click", function () {
        $('body').trigger('processStart');
        openQuickViewModal(); 
        if ($('#QuickViewPopupCloseButton').val()=='') {
          $('.modal-footer').hide();
        }
      });
      var openQuickViewModal = function () {
        var modalContainer = $("#quickViewContainer" + product_id);
        modalContainer.html(createIframe());
        var iframearea = "#fme_frame" + product_id;
        $(iframearea).on("load", function () {
          $('body').trigger('processStop');
          modalContainer.addClass("product-quickview");
          modalContainer.modal('openModal');
        });
      };
      var createIframe = function () {
        return $('<iframe />', { id: 'fme_frame' + product_id, src: product_url + "?iframe=1" });
      }
      $(".modal-inner-wrap .action-close").click(function(){
        var sections = ['cart'];
        customerData.invalidate(sections);
        customerData.reload(sections, true);
      });
    };
  }

  ); 
<?php
/**
 * FME Extensions
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the fmeextensions.com license that is
 * available through the world-wide-web at this URL:
 * https://www.fmeextensions.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  FME
 * @package   FME_QuickView
 * @copyright Copyright (c) 2019 FME (http://fmeextensions.com/)
 * @license   https://fmeextensions.com/LICENSE.txt
 */
namespace FME\QuickView\Block;

class QuickView extends \Magento\Framework\View\Element\Template
{
	public $_quickviewhelper;
	public $_request;

	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\FME\QuickView\Helper\Data $quickviewhelper,
		\Magento\Framework\App\Request\Http $request,
    	array $data = []
		
	) {
		parent::__construct($context, $data);
		$this->_quickviewhelper = $quickviewhelper;
		$this->_request = $request;
	}

}

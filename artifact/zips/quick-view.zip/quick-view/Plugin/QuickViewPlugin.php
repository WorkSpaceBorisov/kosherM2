<?php
/**
 * FME Extensions
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the fmeextensions.com license that is
 * available through the world-wide-web at this URL:
 * https://www.fmeextensions.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  FME
 * @package   FME_QuickView
 * @copyright Copyright (c) 2019 FME (http://fmeextensions.com/)
 * @license   https://fmeextensions.com/LICENSE.txt
 */ 
namespace FME\QuickView\Plugin;

class QuickViewPlugin
{

	protected $_quickviewhelper;

	public function __construct(
		\Magento\Framework\UrlInterface $urlInterface,
		\FME\QuickView\Helper\Data $quickviewhelper,
		\Magento\Framework\View\Element\BlockFactory $blockFactory
	) {
		$this->urlInterface = $urlInterface;
		$this->_quickviewhelper = $quickviewhelper;
		$this->blockFactory = $blockFactory;
	}


	public function afterToHtml(\Magento\Catalog\Pricing\Render\FinalPriceBox $subject, $result)
	{
			
			$id = $subject->getSaleableItem()->getId();
			$quickviewUrl = $subject->getSaleableItem()->getProductUrl($id);
			return $result .= $this->blockFactory->createBlock('\FME\QuickView\Block\QuickView')
                       ->setTemplate('FME_QuickView::product/productlist/item/quickview.phtml')
                       ->setButtonId($id)
                       ->setQuickViewUrl($quickviewUrl)
                       ->toHtml();
	}

}

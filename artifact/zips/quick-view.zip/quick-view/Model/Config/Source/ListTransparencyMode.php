<?php
/**
 * FME Extensions
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the fmeextensions.com license that is
 * available through the world-wide-web at this URL:
 * https://www.fmeextensions.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  FME
 * @package   FME_QuickView
 * @copyright Copyright (c) 2019 FME (http://fmeextensions.com/)
 * @license   https://fmeextensions.com/LICENSE.txt
 */
namespace FME\QuickView\Model\Config\Source;

class ListTransparencyMode implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'ff', 'label' => __('0%')],
        	['value' => 'ee', 'label' => __('10%')],
            ['value' => 'dd', 'label' => __('20%')], 
            ['value' => 'cc', 'label' => __('30%')], 
            ['value' => 'bb', 'label' => __('40%')], 
            ['value' => 'aa', 'label' => __('50%')], 
            ['value' => '88', 'label' => __('60%')], 
            ['value' => '66', 'label' => __('70%')], 
            ['value' => '44', 'label' => __('80%')], 
        	['value' => '22', 'label' => __('90%')], 
        	['value' => '00', 'label' => __('100%')],
        ];
    }
    
}

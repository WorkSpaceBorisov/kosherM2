<?php
/**
* FME Extensions
*
* NOTICE OF LICENSE
*
* This source file is subject to the fmeextensions.com license that is
* available through the world-wide-web at this URL:
* https://www.fmeextensions.com/LICENSE.txt
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this extension to newer
* version in the future.
*
* @category  FME
* @package   FME_QuickView
* @copyright Copyright (c) 2019 FME (http://fmeextensions.com/)
* @license   https://fmeextensions.com/LICENSE.txt
*/
namespace FME\QuickView\Controller\Product;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class View extends \Magento\Catalog\Controller\Product\View
{
/**
* To add new layout handle when product page is loaded in iframe
*
* @return 
\Magento\Framework\Controller\Result\Forward|\Magento\Framework\Controller\Result\Redirect
*/

public function execute() {
	if ($this->getRequest()->getParam("iframe"))
	{ 
		$layout = $this->_view->getLayout(); 
		$layout->getUpdate()->addHandle('product_quickview');
	}
	return parent::execute();
}
}

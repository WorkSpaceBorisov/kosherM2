<?php
/**
 * FME Extensions
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the fmeextensions.com license that is
 * available through the world-wide-web at this URL:
 * https://www.fmeextensions.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  FME
 * @package   FME_QuickView
 * @copyright Copyright (c) 2019 FME (http://fmeextensions.com/)
 * @license   https://fmeextensions.com/LICENSE.txt
 */
namespace FME\QuickView\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class UpdateMessage implements ObserverInterface
{
    /** @var \Magento\Framework\Message\ManagerInterface */
    protected $messageManager;
    public $_quickviewhelper;

    /** @var \Magento\Framework\UrlInterface */
    protected $url;

    public function __construct(
        \Magento\Framework\Message\ManagerInterface $managerInterface,
        \FME\QuickView\Helper\Data $quickviewhelper,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->messageManager = $managerInterface;
        $this->_quickviewhelper = $quickviewhelper;
        $this->url = $url;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {

        if($this->_quickviewhelper->getPopupConfig('button_enable')){

            $messageCollection = $this->messageManager->getMessages(true);
            $cartLink = 'Product Added to Cart Successfully...';
            $messageCollection->getLastAddedMessage()->getText();
            $this->messageManager->addSuccess($messageCollection->getLastAddedMessage()->getText() . '  ' . $cartLink);
        }
    }
}